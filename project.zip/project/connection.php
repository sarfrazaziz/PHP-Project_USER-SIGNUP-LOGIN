<?php
$con=mysqli_connect("localhost","root","","eproject");
// if ($con) {
//     echo"connected";

// }
// else
// {
//     echo"not connected";
// }



?>
