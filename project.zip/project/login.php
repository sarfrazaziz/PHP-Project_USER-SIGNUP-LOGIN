<?php
include("connection.php");
if (isset($_POST['signin'])) {

$username=$_POST['username'];
$password=$_POST['Password'];

$query="select * from admin where email='$username' and password='$password'";
$run=mysqli_query($con,$query);
if ($run) {
    $num=mysqli_num_rows($run);
    if ($num>0) {
        echo"<script>alert('Welcome')</script>";
        header('location:pages/dashboard.php');
    }else
    {
        
             echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Sorry! </strong>Email Or Password Invailed <button type="button" class="close"
        data-dismiss="alert" aria-lable="close">
        <span aria hidden="true">$times;</span>
        </button>
        </div>';
        
    }
}

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>signin</title>
    <!-- Bootstrep css link -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Css link -->
    <link rel="stylesheet" href="style/style.css">
    <!-- Font Awsome -->
    <link rel="stylesheet" href="fontawesome-free-5.15.4-web/css/fontawesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" integrity="sha384-r4NyP46KrjDleawBgD5tp8Y7UzmLA05oM1iAEQ17CSuDqnUK2+k9luXQOfXJCJ4I" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>


</head>
<body>
        <?php
    // if ($Success) {
    //     echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
    //     <strong>Success! </strong> Your login success <button type="button" class="close"
    //     data-dismiss="alert" aria-lable="close">
    //     <span aria hidden="true">$times;</span>
    //     </button>
    //     </div>';
    // }elseif ($invaild) {
        //     echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        // <strong>Sorry! </strong>Invaild Data <button type="button" class="close"
        // data-dismiss="alert" aria-lable="close">
        // <span aria hidden="true">$times;</span>
        // </button>
        // </div>';
    // }
     ?>
  <div class="container d-flex align-items-center justify-content-center">
    <div class="card signin-card">
        <!-- card header -->
        <div class="card-header">
            <h3 class="text-center">Sign In</h3>
        </div>
        <!-- card body   -->
        <div class="card-body">
        <form method="post">
            <!-- first field  -->

            <div class="input-group mb-3">
                <span class="input-group-text"><i class="fa fa-book" aria-hidden="true"></i></span>
                <input type="text" class="form-control" placeholder="Enter your username"
                required="requried" aurocomplete="off" name="username" 
                aria-describodby="basic-addoni">
            </div>
            <!-- second field -->
            <div class="input-group mb-3">
                <span class="input-group-text"><!--i class="fa-solid fa-user"-->@</span>
                <input type="Password" class="form-control" placeholder="Enter your Password"
                required="requried" aurocomplete="off" name="Password" 
                aria-describodby="basic-addoni">
            </div>
            <!-- third field -->
       
            <!-- signup button -->
            <div class="form-group">
                <input type="submit" name="signin"class="btn signup_btn">
            </div>
        </form>
        </div>
        <!-- card footer -->
        <div class="card-footer text-center text-light signup" >
            Dont have an account?  <a href="reg.php"> Sign up </a>
        </div>
    </div>
  </div>  
</body>
</html>