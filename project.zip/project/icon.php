<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="fontawesome-free-5.15.4-web/css/fontawesome.min.css">
    <link rel="stylesheet" href="fontawesome-free-5.15.4-web/css/fontawesome.css">
    <!-- C:\wamp64\www\Eproject\DashboardTemplate\fontawesome-free-5.15.4-web\css\fontawesome.css -->
</head>
<body>
    <i class="fa fa-address-book" aria-hidden="true"></i>
</body>
</html>