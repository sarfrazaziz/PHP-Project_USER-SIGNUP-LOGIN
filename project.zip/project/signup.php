 <?php
// $con=mysqli_connect("localhost","root","","tech");
// if ($con) {
//  echo"connected";
// }
// // $btn=$_POST['btn'];
// if (isset($_POST['btn'])) {
//     $name=$_POST['email'];
//     $pass=$_POST['pass'];
    

// $insert="INSERT INTO `test`(`email`, `pass`) VALUES ('$name','$pass')";
// $query=mysqli_query($con,$insert);
// if ($query) {
//     echo"<script>alert('inserted')</script>";
// }
// else{
//     mysqli_error($con);
//     //  echo"<script>alert('not inserted')</script>";
// }
// }else{
//     echo"not comming";
// }

?>

<?php
  include('connection.php');
//   $con=mysqli_connect('localhost','root','','tech');
// $con=mysqli_connect("localhost","root","","tech");
if (isset($_POST['register'])) {
    // include('connection.php');
    $name=$_POST['name'];
    $contact=$_POST['contact'];
    $email=$_POST['email'];
    $pass=$_POST['Password'];

    $insert2="INSERT INTO `admin`(`name`, `email`, `contect`, `password`) 
    VALUES ('$name','$email','$contact','$pass')";
    $run3=mysqli_query($con, $insert2);
    if ($run3) {
        
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success! </strong>Account Created Successfully <button type="button" class="close"
        data-dismiss="alert" aria-lable="close">
        <span aria hidden="true">$times;</span>
        </button>
        </div>';

    }else {
        echo mysqli_error($con);
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Sorry! </strong> Your Account is already exist <button type="button" class="close"
        data-dismiss="alert" aria-lable="close">
        <span aria hidden="true">$times;</span>
        </button>
        </div>';
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <!-- Bootstrep css link -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Css link -->
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
  <div class="container d-flex align-items-center justify-content-center">
    <div class="card">
        <!-- card header -->
        <div class="card-header">
            <h3 class="text-center">Sign up</h3>
        </div>
        <!-- card body   -->
        <div class="card-body">
        <form method='post'>
            <!-- Name field  -->
            <div class="input-group mb-3">
                <span class="input-group-text"><!--i class="fa-solid fa-user"-->@</span>
                <input type="text" class="form-control" placeholder="Enter your username"
                required="requried" aurocomplete="off" name="name" 
                aria-describodby="basic-addoni">
            </div>
            <!-- Email field  -->
            <div class="input-group mb-3">
                <span class="input-group-text"><!--i class="fa-solid fa-user"-->@</span>
                <input type="email" class="form-control" placeholder="Enter your Email"
                required="requried" aurocomplete="off" name="email" 
                aria-describodby="basic-addoni">
            </div>
            <!-- Contact field -->
            <div class="input-group mb-3">
                <span class="input-group-text"><!--i class="fa-solid fa-user"-->@</span>
                <input type="text" class="form-control" placeholder="Enter your Contact"
                required="requried" aurocomplete="off" name="contact" 
                aria-describodby="basic-addoni">
            </div>
            <!-- Password field -->
            <div class="input-group mb-3">
                <span class="input-group-text"><!--i class="fa-solid fa-user"-->@</span>
                <input type="Password" class="form-control" placeholder="Enter your Password"
                required="requried" aurocomplete="off" name="Password" 
                aria-describodby="basic-addoni">
            </div>
            <!-- third field -->
            <div class="input-group mb-3">
                <span class="input-group-text"><!--i class="fa-solid fa-user"-->@</span>
                <input type="Password" class="form-control" placeholder="Conform your Password"
                required="requried" aurocomplete="off" name="passwordc" 
                aria-describodby="basic-addoni">
            </div>
            <!-- signup button -->
            <div class="form-group">
                <input type="submit" name="register"class="btn signup_btn">
            </div>
        </form>
        </div>
        <!-- card footer -->
        <div class="card-footer text-center text-light signup" >
            Already have an account?  <a href="signin.php"> Sign In </a>
        </div>
    </div>
  </div>  
</body>
</html>